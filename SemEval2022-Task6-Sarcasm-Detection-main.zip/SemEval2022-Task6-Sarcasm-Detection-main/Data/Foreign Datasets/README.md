We used different datasets to acheive better performance. Datasets are available in <a href="https://drive.google.com/drive/folders/1NSXGPRQnuSP2ipNG6-I-7FF-tR9iZvVE?usp=sharing">this link</a>

Datasets are:

* Sarcasm Headlines Dataset
* Sarcasm Headlines Dataset v2.0
* SPIRS
* Twitter US Airline Sentiment 
* Sentiment140 dataset 
* Twitter News Dataset